package quartz

type QuartzLevel string

const (
	QUARTZ_LVL_A QuartzLevel = "A"
	QUARTZ_LVL_B QuartzLevel = "B"
	QUARTZ_LVL_C QuartzLevel = "C"
	QUARTZ_LVL_D QuartzLevel = "D"
	QUARTZ_LVL_E QuartzLevel = "E"
	QUARTZ_LVL_F QuartzLevel = "F"
	QUARTZ_LVL_G QuartzLevel = "G"
	QUARTZ_LVL_H QuartzLevel = "H"
	QUARTZ_LVL_I QuartzLevel = "I"
	QUARTZ_LVL_J QuartzLevel = "J"
	QUARTZ_LVL_K QuartzLevel = "K"
	QUARTZ_LVL_L QuartzLevel = "L"
	QUARTZ_LVL_M QuartzLevel = "M"
	QUARTZ_LVL_N QuartzLevel = "N"
	QUARTZ_LVL_O QuartzLevel = "O"
	QUARTZ_LVL_P QuartzLevel = "P"
	QUARTZ_LVL_Q QuartzLevel = "Q"
	QUARTZ_LVL_R QuartzLevel = "R"
	QUARTZ_LVL_S QuartzLevel = "S"
	QUARTZ_LVL_T QuartzLevel = "T"
	QUARTZ_LVL_U QuartzLevel = "U"
	QUARTZ_LVL_V QuartzLevel = "V"
	QUARTZ_LVL_W QuartzLevel = "W"
	QUARTZ_LVL_X QuartzLevel = "X"
	QUARTZ_LVL_Y QuartzLevel = "Y"
	QUARTZ_LVL_Z QuartzLevel = "Z"
)
