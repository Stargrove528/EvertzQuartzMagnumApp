# Magnum Router

Implements a library for golang projects to connect to an Evertz Magnum server over Quartz Protocol.
Uses [github.com/cassaram/quartz](https://github.com/cassaram/quartz) for Quartz protocol implementation.
