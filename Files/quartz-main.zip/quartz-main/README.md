# Quartz

This library implements the Evertz Quartz router control protocol. Note: This library implements only the protocol. It is recommended to use [github.com/cassaram/magnumrouter](https://github.com/cassaram/magnumrouter) to implement a router interface instead, which uses this library.
